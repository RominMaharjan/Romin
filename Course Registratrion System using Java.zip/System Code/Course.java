/**
 * This Course class is a parent class of two subclasses AcademicCourse and NonAcademicCourse class.
 * It has four attributes they are : CourseID, CourseName, CourseLeader and Duration.
 * 
 * @aurthor(Romin Maharjan)
 * London Met.ID (20048986)
 * 
 */
public class Course
{
     // Here are 4 attributes with their respective datatype
    private String CourseID;
    private String CourseName;
    private String CourseLeader;
    private int Duration;
    /**
     * Here, Constructor for object of Course class
     */
    public Course(String CourseID, String CourseName, int Duration)
    {
        // Initialize Instance variables
        this.CourseID=CourseID;
        this.CourseName=CourseName;
        this.Duration=Duration;
        this.CourseLeader= "";
    }
    
    /**
     * Accessor methods for all attributes:
     */
    public String getCourseID()
    {
        return CourseID;
    }
    public String getCourseName()
    {
        return CourseName;
    }
    public int getDuration()
    {
        return Duration;
    }
    
    public String getCourseLeader()
    {
        return CourseLeader;
    }
    
    /**
     * This method is created to set Course Leader's name
     */
    public void setCourseLeader(String newCourseLeader)
    {
        this.CourseLeader = newCourseLeader;
    }
    
    /**
     * Display method
     */
    public void display()
    {
        System.out.println("The Course ID of the course is "+ CourseID);
        System.out.println("The Name of the course is "+ CourseName);
        System.out.println("The Duration of the course is "+ Duration);
        if (CourseLeader!= "")
        {
            System.out.println("The name of the Course Leader is " +getCourseLeader());
        }
    }
}