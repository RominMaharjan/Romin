/**
 * Creating GUI for Course class, AcademicCourse class, and NonAcademicCourse class.
 * 
 * @author (Romin Maharjan)
 * @London Met.ID (20048986)
 */

//Importing several components of java
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.border.*;

public class INGCollege extends JFrame implements ActionListener
{
    private ArrayList<Course> Course_ArrayList = new ArrayList<Course>(); //Creating Arraylist for Course.

    //Declaring frame and panel
    private JFrame frame;
    private JPanel  panel1, panel2;

    //Declaring several objects for Labels
    private JLabel lblAcademic, lblNonAcademic, lblLine1, lblLine2, lblLine3, lblLine4, lblLine5, lblLineHalf, lblAcaCourseID, lblAcaCourseName,
    lblAcaDuration, lblAcaCredit,lblAcaLevel, lblAcaNumofAssessments, lblAcaLecturer, lblAcaLeader, lblAcaStartDate, lblAcaEndDate, 
    lblNonCourseID, lblNonCourseName, lblNonDuration, lblNonPrerequisite, lblNonLeader, lblNonInstructor, lblNonExamDate, 
    lblNonStartDate, lblNonEndDate, lblImageFrame, lblImage1, lblImage2, islington, LMU, lblWelText;

    //Declaring several objects for text fields
    private JTextField txtAcaCourseID, txtAcaCourseName, txtAcaDuration, txtAcaCredit, txtAcaNumofAssessments, txtAcaLevel, txtAcaLeader, txtAcaLecturer,
    txtAcaStartDate, txtAcaEndDate, txtNonExamDate, txtNonCourseID, txtNonCourseName, txtNonDuration, txtNonPrerequisite, txtNonLeader, 
    txtNonInstructor, txtNonStartDate, txtNonEndDate;

    //Declaring several objects for buttons
    private JButton btnAcademic, btnNonAcademic, btnAcaAdd, btnAcaClear, btnAcaDisplay, btnAcaRegister, btnBack, btnNonAdd, btnNonDisplay, btnNonRegister, 
    btnNonRemove, btnNonClear, btnCancel;

    public INGCollege() //Creating Constructor
    {    

        //Declaring Boders for text field
        Border line = new LineBorder(Color.BLACK);
        Border margin = new EmptyBorder(5, 15, 5, 15);
        Border compound = new CompoundBorder(line, margin);

        //Creating a frame
        frame = new JFrame("ingCollege Course Registration");
        frame.setBounds(400,200,800, 500); //setting coordinates: x, y, width, height
        frame.setLayout(null);

        //Creating and adding Academic Course button  in frame
        btnAcademic = new JButton("Academic Course");
        btnAcademic.setBounds(100, 25, 300, 40);
        frame.add(btnAcademic);//adding buttons into frame
        btnAcademic.setFont(new Font("Times New Roman", Font.BOLD, 22)); //setting font properties
        btnAcademic.setBorder(compound);//adding borders in button
        btnAcademic.addActionListener(this);//adding actionListener in button to make it functionable

        //Creating and adding Non Academic Course button  in frame
        btnNonAcademic = new JButton("Non Academic Course");
        btnNonAcademic.setBounds(450, 25, 300, 40);
        frame.add(btnNonAcademic);//adding buttons into frame
        btnNonAcademic.setFont(new Font("Times New Roman", Font.BOLD, 22));//setting font properties
        btnNonAcademic.setBorder(compound);//adding borders in button
        btnNonAcademic.addActionListener(this); //adding actionListener in button to make it functionable

        //Welcome text in frame
        lblWelText = new JLabel("Welcome to ING College!  Please select your course type :)");
        lblWelText.setBounds(150, 425, 600, 30);
        frame.add(lblWelText);

        //Main button colors
        btnAcademic.setBackground(Color.RED);//setting background color
        btnNonAcademic.setBackground(Color.RED);//setting background color

        //===============================================================//
        //=============Creating pannel for Academic Course===============//
        //===============================================================//

        panel1 = new JPanel();                  
        panel1.setSize(800,500);
        panel1.setLayout(null);
        frame.add(panel1); //Adding panel into frame

        //Adding components in Academic Course
        lblAcademic = new JLabel("Academic Course");
        lblAcademic.setBounds(300, 85, 500, 25);
        panel1.add(lblAcademic);
        lblAcademic.setFont(new Font("Times New Roman", Font.BOLD, 25));
        lblAcademic.setForeground(Color.GREEN);//setting font color

        lblLine1 = new JLabel("_______________________________________________________________________________________________________________________________");
        lblLine1.setBounds(5, 90, 850, 25);
        panel1.add(lblLine1);

        lblAcaCourseID = new JLabel("Course ID :");
        lblAcaCourseID.setBounds(20, 130, 150, 25);
        panel1.add(lblAcaCourseID);

        txtAcaCourseID = new JTextField();
        txtAcaCourseID.setBounds(140, 130, 200, 25);
        panel1.add(txtAcaCourseID);
        txtAcaCourseID.setBorder(compound);

        lblAcaCourseName = new JLabel("Course Name :");
        lblAcaCourseName.setBounds(20, 170, 150, 25);
        panel1.add(lblAcaCourseName);

        txtAcaCourseName = new JTextField();
        txtAcaCourseName.setBounds(140, 170, 250, 25);
        panel1.add(txtAcaCourseName);
        txtAcaCourseName.setBorder(compound);

        lblAcaDuration = new JLabel("Duration :");
        lblAcaDuration.setBounds(515, 130, 150, 25);
        panel1.add(lblAcaDuration);

        txtAcaDuration = new JTextField();
        txtAcaDuration.setBounds(600, 130, 150, 25);
        panel1.add(txtAcaDuration);
        txtAcaDuration.setBorder(compound);

        lblAcaNumofAssessments = new JLabel("No. of Assessments :");
        lblAcaNumofAssessments.setBounds(450, 170, 150, 25);
        panel1.add(lblAcaNumofAssessments);

        txtAcaNumofAssessments = new JTextField();
        txtAcaNumofAssessments.setBounds(600, 170, 150, 25);
        panel1.add(txtAcaNumofAssessments);
        txtAcaNumofAssessments.setBorder(compound);

        lblAcaCredit = new JLabel("Credit Hours :");
        lblAcaCredit.setBounds(20, 210, 150, 25 );
        panel1.add(lblAcaCredit);

        txtAcaCredit = new JTextField();
        txtAcaCredit.setBounds(140, 210, 100, 25);
        panel1.add(txtAcaCredit);
        txtAcaCredit.setBorder(compound);

        lblAcaLevel = new JLabel("Level :");
        lblAcaLevel.setBounds(300, 210, 150, 25);
        panel1.add(lblAcaLevel);

        txtAcaLevel = new JTextField();
        txtAcaLevel.setBounds(360, 210, 150, 25);
        panel1.add(txtAcaLevel);
        txtAcaLevel.setBorder(compound);

        //Add Button 
        ImageIcon addIcon = new ImageIcon("image/btnAdd.png");//creating object for image icon
        btnAcaAdd = new JButton("Add",addIcon); //creatinng button with icon
        btnAcaAdd.setBounds(620, 210, 100, 30);
        panel1.add(btnAcaAdd); //adding button to panel
        btnAcaAdd.setBorder(compound); //adding borders in buttons
        btnAcaAdd.addActionListener(this); //adding actionListener in button to make it functionable

        lblLine2 = new JLabel("____________________________________________________________________________________________________");
        lblLine2.setBounds(20, 230, 600, 25);
        panel1.add(lblLine2);

        lblAcaLeader = new JLabel("Course Leader :");
        lblAcaLeader.setBounds(20, 260, 150, 25);
        panel1.add(lblAcaLeader);

        txtAcaLeader = new JTextField();
        txtAcaLeader.setBounds(140, 260, 200, 25);
        panel1.add(txtAcaLeader);
        txtAcaLeader.setBorder(compound);

        lblAcaLecturer = new JLabel("Lecturer Name :");
        lblAcaLecturer.setBounds(20, 300, 150, 25);
        panel1.add(lblAcaLecturer);

        txtAcaLecturer = new JTextField();
        txtAcaLecturer.setBounds(140, 300, 200, 25);
        panel1.add(txtAcaLecturer);
        txtAcaLecturer.setBorder(compound);

        lblAcaStartDate = new JLabel("Starting Date :");
        lblAcaStartDate.setBounds(420, 260, 150, 25);
        panel1.add(lblAcaStartDate);

        txtAcaStartDate = new JTextField();
        txtAcaStartDate.setBounds(535, 260, 200, 25);
        panel1.add(txtAcaStartDate);
        txtAcaStartDate.setBorder(compound);

        lblAcaEndDate = new JLabel("Completion Date :");
        lblAcaEndDate.setBounds(395, 300, 150, 25);
        panel1.add(lblAcaEndDate);

        txtAcaEndDate = new JTextField();
        txtAcaEndDate.setBounds(535, 300, 200, 25);
        panel1.add(txtAcaEndDate);
        txtAcaEndDate.setBorder(compound);

        //Buttons for Academic Course
        btnAcaDisplay = new JButton("Display", new ImageIcon("image/btnDisplay.png"));
        btnAcaDisplay.setBounds(360, 340, 120, 30);
        panel1.add(btnAcaDisplay);
        btnAcaDisplay.setBorder(compound);
        btnAcaDisplay.addActionListener(this);

        btnAcaRegister = new JButton("Register", new ImageIcon("image/btnRegister.png"));
        btnAcaRegister.setBounds(140, 340, 120, 30);
        panel1.add(btnAcaRegister);
        btnAcaRegister.setBorder(compound);
        btnAcaRegister.addActionListener(this);

        btnAcaClear = new JButton("Clear", new ImageIcon("image/btnClear.png"));
        btnAcaClear.setBounds(620, 340, 100, 30);
        panel1.add(btnAcaClear);
        btnAcaClear.setBorder(compound);
        btnAcaClear.addActionListener(this);

        btnBack = new JButton("Go Back", new ImageIcon("image/btnBack.png"));
        btnBack.setBounds(620, 415, 120, 35);
        panel1.add(btnBack);
        btnBack.setBorder(compound);
        btnBack.addActionListener(this);

        //Setting Font size for Label in Academic Course
        Font fon = new Font("Times New Roman", Font.BOLD, 16);

        lblAcaCourseID.setFont(fon);
        lblAcaCourseName.setFont(fon);
        lblAcaDuration.setFont(fon);
        lblAcaLevel.setFont(fon);
        lblAcaCredit.setFont(fon);
        lblAcaNumofAssessments.setFont(fon);
        lblAcaLeader.setFont(fon);
        lblAcaLecturer.setFont(fon);
        lblAcaStartDate.setFont(fon);
        lblAcaEndDate.setFont(fon);

        //Setting Font Size for TextField in Academic Course
        Font txt = new Font("Times New Roman", Font.PLAIN, 16);

        txtAcaCourseID.setFont(txt);
        txtAcaCourseName.setFont(txt);
        txtAcaDuration.setFont(txt);
        txtAcaCredit.setFont(txt);
        txtAcaLevel.setFont(txt);
        txtAcaNumofAssessments.setFont(txt);
        txtAcaLeader.setFont(txt);
        txtAcaLecturer.setFont(txt);
        txtAcaStartDate.setFont(txt);
        txtAcaEndDate.setFont(txt);

        //Creating Half-line
        lblLineHalf = new JLabel("_________________________________________________________________________________________________________________________");
        lblLineHalf.setBounds(5, 380, 800, 25);
        panel1.add(lblLineHalf);

        //===============================================================//
        //==============Creating panel for NonAcademic Course============//
        //===============================================================//

        panel2 = new JPanel();                        
        panel2.setSize(800,500);
        panel2.setLayout(null);         
        frame.add(panel2);//adding panel into frame

        //Adding Components in Non-Academic Course
        lblNonAcademic = new JLabel("Non-Academic Course");
        lblNonAcademic.setBounds(300, 85, 500, 25);
        panel2.add(lblNonAcademic);
        lblNonAcademic.setFont(new Font("Times New Roman", Font.BOLD, 25));
        lblNonAcademic.setForeground(Color.GREEN);

        lblLine3 = new JLabel("_________________________________________________________________________________________________________________________");
        lblLine3.setBounds(5, 90, 800, 25);
        panel2.add(lblLine3);

        lblNonCourseID = new JLabel("Course ID :");
        lblNonCourseID.setBounds(20, 130, 150, 25);
        panel2.add(lblNonCourseID);

        txtNonCourseID = new JTextField();
        txtNonCourseID.setBounds(140, 130, 200, 25);
        panel2.add(txtNonCourseID);
        txtNonCourseID.setBorder(compound);

        lblNonCourseName = new JLabel("Course Name :");
        lblNonCourseName.setBounds(20, 170, 150, 25);
        panel2.add(lblNonCourseName);

        txtNonCourseName = new JTextField();
        txtNonCourseName.setBounds(140, 170, 250, 25);
        panel2.add(txtNonCourseName);
        txtNonCourseName.setBorder(compound);

        lblNonDuration = new JLabel("Duration :");
        lblNonDuration.setBounds(515, 130, 150, 25);
        panel2.add(lblNonDuration);

        txtNonDuration = new JTextField();
        txtNonDuration.setBounds(600, 130, 150, 25);
        panel2.add(txtNonDuration);
        txtNonDuration.setBorder(compound);

        lblNonPrerequisite = new JLabel("Prerequisite :");
        lblNonPrerequisite.setBounds(500, 170, 150, 25);
        panel2.add(lblNonPrerequisite);

        txtNonPrerequisite = new JTextField();
        txtNonPrerequisite.setBounds(600, 170, 150, 25);
        panel2.add(txtNonPrerequisite);
        txtNonPrerequisite.setBorder(compound);

        //Add Button for Non Academic Course
        btnNonAdd = new JButton("Add", new ImageIcon("image/btnAdd.png"));
        btnNonAdd.setBounds(620, 210, 100, 30);
        panel2.add(btnNonAdd);
        btnNonAdd.setBorder(compound);
        btnNonAdd.addActionListener(this);

        //Underline 
        lblLine4 = new JLabel("____________________________________________________________________________________________________");
        lblLine4.setBounds(20, 230, 600, 25);
        panel2.add(lblLine4);

        lblNonLeader = new JLabel("Course Leader :");
        lblNonLeader.setBounds(20, 260, 150, 25);
        panel2.add(lblNonLeader);

        txtNonLeader = new JTextField();
        txtNonLeader.setBounds(140, 260, 200, 25);
        panel2.add(txtNonLeader);
        txtNonLeader.setBorder(compound);

        lblNonInstructor = new JLabel("Instructor Name :");
        lblNonInstructor.setBounds(20, 300, 150, 25);
        panel2.add(lblNonInstructor);

        txtNonInstructor = new JTextField();
        txtNonInstructor.setBounds(140, 300, 200, 25);
        panel2.add(txtNonInstructor);
        txtNonInstructor.setBorder(compound);

        lblNonExamDate = new JLabel("Exam Date :");
        lblNonExamDate.setBounds(20, 340, 150, 25);
        panel2.add(lblNonExamDate);

        txtNonExamDate = new JTextField();
        txtNonExamDate.setBounds(140, 340, 200, 25);
        panel2.add(txtNonExamDate);
        txtNonExamDate.setBorder(compound);

        lblNonStartDate = new JLabel("Starting Date :");
        lblNonStartDate.setBounds(420, 260, 150, 25);
        panel2.add(lblNonStartDate);

        txtNonStartDate = new JTextField();
        txtNonStartDate.setBounds(535, 260, 200, 25);
        panel2.add(txtNonStartDate);
        txtNonStartDate.setBorder(compound);

        lblNonEndDate = new JLabel("Completion Date :");
        lblNonEndDate.setBounds(395, 300, 150, 25);
        panel2.add(lblNonEndDate);

        txtNonEndDate = new JTextField();
        txtNonEndDate.setBounds(535, 300, 200, 25);
        panel2.add(txtNonEndDate);
        txtNonEndDate.setBorder(compound);

        //Buttons for Non Academic Course 
        btnNonDisplay = new JButton("Display", new ImageIcon("image/btnDisplay.png"));
        btnNonDisplay.setBounds(360, 380, 120, 30);
        panel2.add(btnNonDisplay);
        btnNonDisplay.setBorder(compound);
        btnNonDisplay.addActionListener(this);

        btnNonClear = new JButton("Clear", new ImageIcon("image/btnClear.png"));
        btnNonClear.setBounds(620, 340, 100, 30);
        panel2.add(btnNonClear);
        btnNonClear.setBorder(compound);
        btnNonClear.addActionListener(this);

        btnNonRegister = new JButton("Register", new ImageIcon("image/btnRegister.png"));
        btnNonRegister.setBounds(140, 380, 120, 30);
        panel2.add(btnNonRegister);
        btnNonRegister.setBorder(compound);
        btnNonRegister.addActionListener(this);

        btnNonRemove = new JButton("Remove", new ImageIcon("image/btnRemove.png"));
        btnNonRemove.setBounds(620, 380, 120, 30);
        panel2.add(btnNonRemove);
        btnNonRemove.setBorder(compound);
        btnNonRemove.addActionListener(this);

        btnCancel = new JButton("Exit", new ImageIcon("image/btnExit.png"));
        btnCancel.setBounds(620, 430, 120, 30);
        panel2.add(btnCancel);
        btnCancel.setBorder(compound);
        btnCancel.addActionListener(this);

        lblLine5 = new JLabel("_________________________________________________________________________________________________________________________");
        lblLine5.setBounds(5, 405, 800, 25);
        panel2.add(lblLine5);

        //Setting Font Size for Label in Non Academic Course
        lblNonCourseID.setFont(fon);
        lblNonCourseName.setFont(fon);
        lblNonDuration.setFont(fon);
        lblNonPrerequisite.setFont(fon);
        lblNonLeader.setFont(fon);
        lblNonInstructor.setFont(fon);
        lblNonExamDate.setFont(fon);
        lblNonStartDate.setFont(fon);
        lblNonEndDate.setFont(fon);

        //Setting Font Size for TextField in Non Academic Course
        txtNonCourseID.setFont(txt);
        txtNonCourseName.setFont(txt);
        txtNonDuration.setFont(txt);
        txtNonPrerequisite.setFont(txt);
        txtNonLeader.setFont(txt);
        txtNonInstructor.setFont(txt);
        txtNonStartDate.setFont(txt);
        txtNonEndDate.setFont(txt);
        txtNonExamDate.setFont(txt);

        //===================================================//
        //==========Logo of ING Group for front frame========//

        ImageIcon addLogoframe = new ImageIcon("image/setBack.png");
        lblImageFrame = new JLabel(addLogoframe);
        lblImageFrame.setBounds(300,50, 400,300);
        frame.add(lblImageFrame);

        ImageIcon addLogo3 = new ImageIcon("image/islington.png");
        islington = new JLabel(addLogo3);//adding image into label
        islington.setBounds(0,100, 300,200);
        frame.add(islington);//adding image on frame

        ImageIcon addLogo4 = new ImageIcon("image/LMU.png");
        LMU = new JLabel(addLogo4);
        LMU.setBounds(120,310, 400,100);
        frame.add(LMU);

        //Logo of ING for Academic and Non-Academic Course
        ImageIcon addLogo1 = new ImageIcon("image/ingSmallLogo.png");
        lblImage1 = new JLabel(addLogo1);
        lblImage1.setBounds(0,40, 100,70);
        panel1.add(lblImage1);//adding Image in panel1

        ImageIcon addLogo2 = new ImageIcon("image/ingSmallLogo.png");
        lblImage2 = new JLabel(addLogo2);
        lblImage2.setBounds(0,40, 100,70);
        panel2.add(lblImage2);//adding Image on panel2

        //===================================================//
        //=======setting Visibility of frame and panel=======//

        frame.setVisible(true); //frame will be visible when program runs
        panel1.setVisible(false); //Panel wont be visible at first
        panel2.setVisible(false); //Panel wont be visible at first
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//For closing program
        frame.setIconImage(new ImageIcon("image/ingLogo.png").getImage());//adding image icon on the top
        frame.setResizable(false);//frame cannt be resiable
        frame.setLocationRelativeTo(null);

        //=========frame panel Colors========//
        Color backGround = new Color(0x343A40);
        frame.setBackground(backGround);
        panel1.setBackground(backGround);//adding background color in panel
        panel2.setBackground(backGround);
        lblWelText.setForeground(new Color(0x343A40));//adding color in font
        lblWelText.setFont(new Font("Times New Roman", Font.BOLD, 18));

        //adding Colors in Label 
        Color lblcol = new Color(0xfffafa);

        //Button
        btnAcademic.setForeground(lblcol);//adding color in font
        btnNonAcademic.setForeground(lblcol);

        //adding Colors in Label Academic
        lblAcaCourseID.setForeground(lblcol);
        lblAcaCourseName.setForeground(lblcol);
        lblAcaDuration.setForeground(lblcol);
        lblAcaLevel.setForeground(lblcol);
        lblAcaCredit.setForeground(lblcol);
        lblAcaNumofAssessments.setForeground(lblcol);
        lblAcaLeader.setForeground(lblcol);
        lblAcaLecturer.setForeground(lblcol);
        lblAcaStartDate.setForeground(lblcol);
        lblAcaEndDate.setForeground(lblcol);

        //adding Colors in Label Non-Academic
        lblNonCourseID.setForeground(lblcol);
        lblNonCourseName.setForeground(lblcol);
        lblNonDuration.setForeground(lblcol);
        lblNonPrerequisite.setForeground(lblcol);
        lblNonLeader.setForeground(lblcol);
        lblNonInstructor.setForeground(lblcol);
        lblNonExamDate.setForeground(lblcol);
        lblNonStartDate.setForeground(lblcol);
        lblNonEndDate.setForeground(lblcol);

        //adding Colors in Line 
        Color lincol = new Color(0x0466C8);
        lblLine1.setForeground(lincol);
        lblLine3.setForeground(lincol);

        Color halfcol = new Color(0x90A955);
        lblLineHalf.setForeground(halfcol);
        lblLine5.setForeground(halfcol);

        Color linCol = new Color(0xF08080);
        lblLine2.setForeground(linCol);
        lblLine4.setForeground(linCol);

        //adding Colors in Buttons 
        Color btnCol = new Color(0xA2D2FF);
        btnAcaAdd.setBackground(btnCol);
        btnNonAdd.setBackground(btnCol);

        Color btnCOL = new Color(0x80FFDB);

        btnAcaRegister.setBackground(btnCOL);
        btnAcaDisplay.setBackground(btnCOL);
        btnAcaClear.setBackground(btnCOL);
        btnNonDisplay.setBackground(btnCOL);
        btnNonRegister.setBackground(btnCOL);
        btnNonRemove.setBackground(btnCOL);
        btnNonClear.setBackground(btnCOL);

        Color btnbk = new Color(0xF94144);
        btnCancel.setBackground(btnbk);
        btnBack.setBackground(btnbk);
        //=============================//

    }

    public static void main(String[]args) //Creating main method
    {
        new INGCollege();  //Calling Constructor
    }

    //============================================================//
    //===========Method for Action event on front Frame =========//

    public void acaButton() // Method for action of Academic Button 
    {
        panel1.setVisible(true); 
        panel2.setVisible(false); 
    }

    public void nonButton() // Method for action of NonAcademic Button
    {
        panel1.setVisible(false);
        panel2.setVisible(true);
    }

    //============================================================//
    //===========Method for Action event on Academic Course=======//

    public void Back() // Method for action of Back Button
    {
        panel1.setVisible(false);
        panel2.setVisible(false);
    }

    public void AcaAdd() //Method for action after clicking Add Button of Academic Course
    {
        try
        {
            String AcaCourseID = txtAcaCourseID.getText(); // getting values from text field
            String AcaCourseName = txtAcaCourseName.getText();
            String AcaCredit = txtAcaCredit.getText();
            String AcaDuration = txtAcaDuration.getText();
            String AcaNumofAssessments = txtAcaNumofAssessments.getText();
            String AcaLevel = txtAcaLevel.getText();

            if(AcaCourseID.isEmpty() || AcaCourseName.isEmpty() || AcaCredit.isEmpty() || AcaDuration.isEmpty() || AcaNumofAssessments.isEmpty() || AcaLevel.isEmpty())//Checking empty fields
            {
                throw new Exception();
            }
            else
            {
                int inAcaDuration = Integer.parseInt(AcaDuration); //Converting String into integer
                int inAcaNumofAssessments = Integer.parseInt(AcaNumofAssessments);
                int inAcaCredit = Integer.parseInt(AcaCredit);

                if(inAcaDuration < 1)//Checking if values are valid or not
                {
                    JOptionPane.showMessageDialog(null, "Please Enter positive value greater than '0' in\n*Duration \n*Credit \n*Number of Assessments ",
                        "Unwanted Value Found :(", JOptionPane.WARNING_MESSAGE);  
                }
                else if (inAcaNumofAssessments < 1)
                {
                    JOptionPane.showMessageDialog(null, "Please Enter positive value greater than '0' in\n*Duration \n*Credit \n*Number of Assessments ",
                        "Unwanted Value Found :(", JOptionPane.WARNING_MESSAGE);  
                }
                else if (inAcaCredit < 1)
                {
                    JOptionPane.showMessageDialog(null, "Please Enter positive value greater than '0' in\n*Duration \n*Credit \n*Number of Assessments ",
                        "Unwanted Value Found :(", JOptionPane.WARNING_MESSAGE);  
                }
                else
                {
                    if (Course_ArrayList.size()==0) //Checking size of arraylist is 0 or not
                    {
                        AcademicCourse AcaCourse = new AcademicCourse(AcaCourseID, AcaCourseName, inAcaDuration , AcaLevel, AcaCredit, inAcaNumofAssessments); //Creating object of Academic class
                        Course_ArrayList.add(AcaCourse); //Adding object of Academic class to arraylist 
                        JOptionPane.showMessageDialog(null,AcaCourseName + " Course has been added as a Academic Course."+"\n Course ID : "+AcaCourseID, "Course Added Successfully :)", JOptionPane.INFORMATION_MESSAGE); //Displays Added message in dialogbox

                    }
                    else if (Course_ArrayList.size() > 0)
                    {
                        for (int i = 0; i < Course_ArrayList.size(); i++)//Starting loop
                        {
                            if((Course_ArrayList.get(i).getCourseID()).equals(AcaCourseID)) //comparing courseID
                            {
                                JOptionPane.showMessageDialog(null,"The course with ID " + AcaCourseID + " has already been added.",
                                    "Duplicate CourseID Detected :(",JOptionPane.ERROR_MESSAGE);
                                break;
                            }
                            else if(!(Course_ArrayList.get(i).getCourseID()).equals(AcaCourseID))
                            {
                                AcademicCourse AcaCourse = new AcademicCourse(AcaCourseID, AcaCourseName, inAcaDuration , AcaLevel, AcaCredit, inAcaNumofAssessments);
                                Course_ArrayList.add(AcaCourse);
                                JOptionPane.showMessageDialog(null,AcaCourseName + " Course has been added as a Academic Course."+"\n Course ID : "+AcaCourseID, "Course Added Successfully :)",JOptionPane.INFORMATION_MESSAGE); 
                                break;
                            }  
                        }
                    }
                }

            }
        }

        catch(NumberFormatException ex)//Catching Number Format exeption
        {
            JOptionPane.showMessageDialog(null, "Please Enter Numerical Value in \n*Duration \n*Credit \n*Number of Assessments",
                "Error in input by user :(", JOptionPane.ERROR_MESSAGE);
        }
        catch(Exception ex) //Catching any posible exception
        {
            JOptionPane.showMessageDialog(null, "Please Enter all the fields", "Blank Fields. :(", //action if any of them is empty
                JOptionPane.WARNING_MESSAGE);
        }                                     
    }

    public void AcaRegister() // Method for Registering course in Academic Course
    {
        try
        {
            String AcaLecturer = txtAcaLecturer.getText(); //getting values feom text field
            String AcaCourseID = txtAcaCourseID.getText();
            String AcaCourseLeader = txtAcaLeader.getText();
            String AcaStartDate = txtAcaStartDate.getText();
            String AcaEndDate = txtAcaEndDate.getText();
            if(AcaLecturer.isEmpty() || AcaCourseLeader.isEmpty() || AcaStartDate.isEmpty() || AcaEndDate.isEmpty())//checking if fields are empty or not
            {    
                throw new Exception();
            }
            else
            {
                if(Course_ArrayList.size()>0) //Checking either course is added or not)
                {
                    for (int i = 0; i<Course_ArrayList.size(); i++)//Starting loop

                    {
                        for(Course course: Course_ArrayList){
                            if(course instanceof AcademicCourse){
                                AcademicCourse acaCourse = (AcademicCourse) course;
                                if((acaCourse.getCourseID()).equals(AcaCourseID))
                                {
                                    if(acaCourse.getIsRegistered() == true)//Checking either course is registred or not
                                    {
                                        JOptionPane.showMessageDialog(null,"The course has already been registered."+"\n Course ID : "+AcaCourseID,
                                            "Already Registered :)", JOptionPane.ERROR_MESSAGE);
                                        break;
                                    }
                                    else if(acaCourse.getIsRegistered() == false)
                                    {
                                        acaCourse.register(AcaCourseLeader, AcaLecturer, AcaStartDate, AcaEndDate);
                                        JOptionPane.showMessageDialog(null, "Course has been Registered Sucessfully :) \n Course ID : "+AcaCourseID, "Successfully Registered :)",
                                            JOptionPane.INFORMATION_MESSAGE);//message dialog
                                        break;
                                    }
                                }
                            }
                            else{
                                JOptionPane.showMessageDialog(frame,"Please enter a valid Course ID which has been added up to the section. "
                                ,"Error, CourseID not found :(", JOptionPane.ERROR_MESSAGE);
                            }

                        }
                    }
                }

                else
                {
                    JOptionPane.showMessageDialog(null, "The Course has not been added yet. \n Please Add Course first to register.", "Please Add Course :(",JOptionPane.WARNING_MESSAGE); 
                }
            }
        }
        catch(Exception ex)//catching exception
        {
            JOptionPane.showMessageDialog(null, "Please Enter all the fields", "Blank Fields. :(", //Message dialog
                JOptionPane.WARNING_MESSAGE);
        }
    }

    public void AcaClear() //Method for action of clear button Academic
    {
        txtAcaCourseID.setText("");//Making textfield empty
        txtAcaCourseName.setText("");
        txtAcaDuration.setText("");
        txtAcaCredit.setText("");
        txtAcaLevel.setText("");
        txtAcaNumofAssessments.setText("");
        txtAcaLeader.setText("");
        txtAcaLecturer.setText("");
        txtAcaStartDate.setText("");
        txtAcaEndDate.setText("");

    }

    //============================================================//
    //===========Method for Action event on NonAcademic Course=======//

    public void NonAdd() //Method for action after clicking Add Button of NonAcademic Course
    {
        try
        {
            String NonCourseID = txtNonCourseID.getText();//Getting values from text fields
            String NonCourseName = txtNonCourseName.getText();
            String NonDuration = txtNonDuration.getText();
            String NonPrerequisite = txtNonPrerequisite.getText();

            if((NonCourseID.isEmpty() || NonCourseName.isEmpty() || NonDuration.isEmpty() || NonPrerequisite.isEmpty()))//Checking either the text field are empty or not
            {
                throw new Exception();
            }
            else
            {
                int inNonDuration = Integer.parseInt(NonDuration); //Conveting String into integer
                if(inNonDuration < 1)//Checking if values are valid or not
                {
                    JOptionPane.showMessageDialog(null, "Please Enter positive value greater than '0' in\n*Duration ",
                        "Unwanted Value Found :(", JOptionPane.WARNING_MESSAGE);  
                }
                else
                {
                    if (Course_ArrayList.size()==0)
                    {
                        NonAcademicCourse NonCourse = new NonAcademicCourse(NonCourseID, NonCourseName, inNonDuration, NonPrerequisite); //Creating object of NonAcademic class
                        Course_ArrayList.add(NonCourse); //Adding NonAcademic Course in arraylist
                        JOptionPane.showMessageDialog(null,NonCourseName + " Course has been added as a NonAcademic Course."+"\n Course ID : "+NonCourseID,
                            "Course Added Successfully :)", JOptionPane.INFORMATION_MESSAGE); //Displays Added message in dialogbox
                    }
                    else if (Course_ArrayList.size() > 0)
                    {
                        for (int i = 0; i < Course_ArrayList.size(); i++)
                        {
                            if(Course_ArrayList.get(i).getCourseID().equals(NonCourseID))
                            {
                                JOptionPane.showMessageDialog(null,"The course with ID " + NonCourseID + " has already been added.",
                                    "Duplicate CourseID Detected :(",JOptionPane.ERROR_MESSAGE);
                                break;
                            }
                            else if(!Course_ArrayList.get(i).getCourseID().equals(NonCourseID))
                            {
                                NonAcademicCourse NonCourse = new NonAcademicCourse(NonCourseID, NonCourseName, inNonDuration, NonPrerequisite);
                                Course_ArrayList.add(NonCourse);
                                JOptionPane.showMessageDialog(null,NonCourseName + " Course has been added as a NonAcademic Course."+"\n Course ID : "+NonCourseID, "Course Added Successfully :)",JOptionPane.INFORMATION_MESSAGE); 
                                break;
                            }  
                        }
                    }
                }

            }
        }

        catch(NumberFormatException ex)//Catching Number Format exeption
        {
            JOptionPane.showMessageDialog(null, "Please Enter Numerical Value in \n*Duration ",
                "Error in input by user :(", JOptionPane.ERROR_MESSAGE);
        }
        catch(Exception ex) //Catching any posible exception
        {
            JOptionPane.showMessageDialog(null, "Please Enter all the fields", "Blank Fields. :(", //action if any of them is empty
                JOptionPane.WARNING_MESSAGE);
        }                                                        
    }

    //Method for registering NonAcademic Course
    public void NonRegister()
    {
        try
        {
            String NonInstructor = txtNonInstructor.getText();//Geting values of text field
            String NonCourseID = txtNonCourseID.getText();
            String NonCourseLeader = txtNonLeader.getText();
            String NonStartDate = txtNonStartDate.getText();
            String NonEndDate = txtNonEndDate.getText();
            String NonExamDate = txtNonExamDate.getText();
            if(NonInstructor.isEmpty() || NonCourseLeader.isEmpty() || NonStartDate.isEmpty() || NonEndDate.isEmpty() || NonExamDate.isEmpty())//Checking either the text field are empty or not
            {    
                throw new Exception();
            }
            else
            {
                if(Course_ArrayList.size()>0) //Checking either course is added or not)
                {
                    for (int i = 0; i<Course_ArrayList.size(); i++)//Starting loop

                    {
                        for(Course course: Course_ArrayList){
                            if(course instanceof NonAcademicCourse){
                                NonAcademicCourse nonCourse = (NonAcademicCourse) course;
                                if((nonCourse.getCourseID()).equals(NonCourseID))
                                {
                                    if(nonCourse.getIsRegistered() == false)
                                    {
                                        nonCourse.register(NonCourseLeader, NonInstructor, NonStartDate, NonEndDate, NonExamDate);
                                        JOptionPane.showMessageDialog(null, "Course has been Registered Sucessfully :) \n Course ID : "+NonCourseID, "Successfully Registered :)",
                                            JOptionPane.INFORMATION_MESSAGE);//message dialog
                                        break;
                                    }
                                    else if(nonCourse.getIsRegistered() == true)
                                    {
                                        JOptionPane.showMessageDialog(null,"The course has already been registered."+"\n Course ID : "+NonCourseID,
                                            "Already Registered :)", JOptionPane.ERROR_MESSAGE);
                                        break;
                                    }
                                }
                            }
                            else{
                                JOptionPane.showMessageDialog(null,"Please enter a valid Course ID which has been added up to the section. "
                                ,"Error, CourseID not found :(", JOptionPane.ERROR_MESSAGE);
                            }

                        }
                    }
                }

                else
                {
                    JOptionPane.showMessageDialog(null, "The Course has not been added yet. \n Please Add Course first to register.", "Please Add Course :(",JOptionPane.WARNING_MESSAGE); 
                }
            }
        }
        catch(Exception ex)//catching exception
        {
            JOptionPane.showMessageDialog(null, "Please Enter all the fields", "Blank Fields. :(", //Message dialog
                JOptionPane.WARNING_MESSAGE);
        }
    }

    public void Display()// MEthod for action of display buttonn of Academic and NonAcademic Course
    {
        if(Course_ArrayList.size()>0)
        {
            for(Course Aca : Course_ArrayList)//Starting loop
            {
                if(Aca instanceof AcademicCourse)
                {
                    AcademicCourse disAca = (AcademicCourse)Aca;
                    System.out.println("******* Registered Course in Academic Course ******* ");
                    disAca.display();
                    System.out.println("________________________________________________________");
                }
                else if(Aca instanceof NonAcademicCourse)
                {
                    NonAcademicCourse disNon = (NonAcademicCourse)Aca;
                    System.out.println("******* Registered Course in NonAcademic Course ******* ");
                    disNon.display();
                    System.out.println("________________________________________________________");
                }
                else
                {
                    System.out.println("Details: ");
                    Aca.display();
                }
            }
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Sorry :( \n No Course Information to display");    
        }
    }

    //Methods for adding action on Clear button of NonAcademicCourse
    public void NonClear()
    {
        txtNonCourseID.setText("");//Making textfield empty
        txtNonCourseName.setText("");
        txtNonDuration.setText("");
        txtNonPrerequisite.setText("");
        txtNonLeader.setText("");
        txtNonInstructor.setText("");
        txtNonStartDate.setText("");
        txtNonEndDate.setText("");
        txtNonExamDate.setText("");
    }

    //Method for adding action on remove button of NonAcademic Course
    public void NonRemove()
    {
        try
        {
            String NonInstructor = txtNonInstructor.getText();//Geting values of text field
            String NonCourseID = txtNonCourseID.getText();
            String NonCourseLeader = txtNonLeader.getText();
            String NonStartDate = txtNonStartDate.getText();
            String NonEndDate = txtNonEndDate.getText();
            String NonExamDate = txtNonExamDate.getText();
            if(NonInstructor.isEmpty() || NonCourseLeader.isEmpty() || NonStartDate.isEmpty() || NonEndDate.isEmpty() || NonExamDate.isEmpty())//Checking either the text field are empty or not
            {    
                throw new Exception();
            }
            else
            {
                for (int i = 0; i< Course_ArrayList.size(); i++)//Starting loop
                {
                    if((Course_ArrayList.get(i).getCourseID()).equals(NonCourseID)) //Checking if CourseID matches or not
                    {
                        NonAcademicCourse nonCourse = (NonAcademicCourse)(Course_ArrayList.get(i));
                        if(nonCourse.IsRemoved == false) //Checking course exist or not
                        {
                            nonCourse.remove(); //Calling remove method
                            JOptionPane.showMessageDialog(null, "Course has been Sucessfully Removed \n Course ID : "+NonCourseID,
                                "Successfully Removed :)",JOptionPane.INFORMATION_MESSAGE); //Message dialog
                            nonCourse.IsRemoved = true;
                        }
                        else
                        {
                            JOptionPane.showMessageDialog(null,"The course has already been removed \n Course iD : "+ NonCourseID,
                                "ERROR Can't remove :(",JOptionPane.ERROR_MESSAGE); //Message dialog
                        }
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null,"Invalid Course ID, please enter an added course ot remove. ",
                            "ERROR :(",JOptionPane.ERROR_MESSAGE);

                    }
                }
            }
        }
        catch(Exception e)//Catching exception
        {
            JOptionPane.showMessageDialog(null,"There are nothing to remove.","ERROR Nothing to Remove",JOptionPane.ERROR_MESSAGE);

        }
    }

    //==============Button Action =============//
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==btnAcademic) //action for Academic button of Academic course
        {
            acaButton();
        }

        if(e.getSource()==btnNonAcademic)//action for  NonAcademic button of NonAcademic course
        {
            nonButton();
        }

        if(e.getSource()==btnBack)//action for back button of Academic course
        {
            Back();
        }

        if (e.getSource()==btnAcaAdd)//action for add button of Academic course
        {
            AcaAdd();
        }

        if(e.getSource()==btnAcaRegister)//action for Register button of Academic course
        {
            AcaRegister();
        }

        if (e.getSource()==btnAcaDisplay)//action for display button of Academic course
        {
            Display();
        }

        if (e.getSource()==btnAcaClear)//action for clear button of Academic course
        {
            AcaClear();
        }

        if (e.getSource()==btnNonAdd)//action for add button of NonAcademic course
        {
            NonAdd();
        }

        if(e.getSource()==btnNonRegister)//action for Register button of NonAcademic course
        {
            NonRegister();
        }

        if (e.getSource()==btnNonDisplay)//action for display button of NonAcademic course
        {
            Display();
        }

        if (e.getSource()==btnNonClear)//action for clear button of NonAcademic course
        {
            NonClear();
        }

        if (e.getSource()==btnNonRemove)//action for Remove button of NonAcademic course
        {
            NonRemove();
        }

        if (e.getSource()==btnCancel)//action for exit button of NonAcademic course
        {
            System.exit(0);
        }

    }
}