/**
 * This AcademicCourse class is a subclass of Course class.
 * It has 7 attributes they are: LecturerName, Level, Credit, StartingDate, CompletionDate, NumberofAssessments and IsRegistered
 * 
 * @aurthor (Romin Maharjan)
 * London Met.ID (20048986)
 */
public class AcademicCourse extends Course
{
    // 6 attributes with their respective datatype.
    private String LecturerName;
    private String Level;
    private String Credit;
    private String StartingDate;
    private String CompletionDate;
    private int NumberofAssessments;
    private boolean IsRegistered;
    /**
     * Here, Constructors for objects of AcademicCourse class.
     */
    
    public AcademicCourse(String CourseID, String CourseName, int Duration, String Level, String Credit, int NumberofAssessments)
    {
       super(CourseID, CourseName, Duration);
       // Initialize Innstance variable
        this.LecturerName="";
        this.Level=Level;
        this.Credit=Credit;
        this.StartingDate="";
        this.CompletionDate="";
        this.NumberofAssessments=NumberofAssessments;
        this.IsRegistered=false;
    }
    /**
     * Accesor methods to return values of respective variables.
     */
    public String getLecturerName()
    {
        return LecturerName;
    }
    public String getLevel()
    {
        return Level;
    }
    public String getCredit()
    {
        return Credit;
    }
    public String getStartingDate()
    {
        return StartingDate;
    }
    public String getCompletionDate()
    {
        return CompletionDate;
    }
    public int getNumberofAssessments()
    {
        return NumberofAssessments;
    }
    public boolean getIsRegistered()
    {
        return IsRegistered;
    }
    /**
     * This method is created to set new Lecturer's name
     */
    public void setLecturerName(String newLecturerName)
    {
        LecturerName=newLecturerName;
    }
    /**
     * This method is created to set number of assessments 
     */
    public void setNumberofAssessments(int newNumberofAssessments)
    {
        NumberofAssessments= newNumberofAssessments;
    }
    /**
     * Method to register the course
     */
    public void register(String CourseLeader, String LecturerName, String StartingDate, String CompletionDate)
    {
        if(this.IsRegistered==true)
        {
            System.out.println("The name of the Lecturer is "+ LecturerName);
            System.out.println("The starting date of the course is "+ StartingDate);
            System.out.println("The completion date of the course is "+ CompletionDate);
        }
        else
        {
            setCourseLeader (CourseLeader);
            this.LecturerName=LecturerName;
            this.StartingDate=StartingDate;
            this.CompletionDate=CompletionDate;
            this.IsRegistered=true;
        }
        
    }
    /**
     * Method to display details of course.
     * It contains same details as the display method of parent class Course.
     */
    public void display()
    {
        super.display();
        if (this.IsRegistered==true)
        {
            System.out.println("The Name of the lecturer is "+ LecturerName);
            System.out.println("The level of the course is "+ Level);
            System.out.println("The credit of the course is "+ Credit);
            System.out.println("The Starting date of the course is "+ StartingDate);
            System.out.println("The Completion date of the course is "+ CompletionDate);
            System.out.println("The number of assessments of the course is "+ NumberofAssessments);
        }
    }
}








