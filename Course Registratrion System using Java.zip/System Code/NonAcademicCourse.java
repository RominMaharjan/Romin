/**
 * This NonAcademicCourse class is a subclass of Course class.
 * It has 7 attributes they are: InstructorName, StartDate, CompletionDate, ExamDate, Prerequisite, IsRegistered and Isremoved
 * 
 * @aurthor (Romin Maharjan)
 * London Met.ID (20048986)
 */
public class NonAcademicCourse extends Course
{
    private String InstructorName;
    private String StartDate;
    private String CompletionDate;
    private String ExamDate;
    private String Prerequisite;
    private boolean IsRegistered;
    public boolean IsRemoved;
    /**
     * Here, Constructor for objects of NonAcademicCourse class.
     */
    public NonAcademicCourse(String CourseID, String CourseName, int Duration, String Prerequisite)
    {
        super(CourseID, CourseName, Duration);
        // Initialize Instance variables
        this.StartDate="";
        this.ExamDate="";
        this.CompletionDate="";
        this.Prerequisite=Prerequisite;
        this.IsRegistered=false;
        this.IsRemoved=false;
    }
    /**
     * Accesor methods to return values of respective variables.
     */
    public String getInstructorName()
    {
        return InstructorName;
    
    }
    public String getStartDate()
    {
        return StartDate;
    }
    public String getCompletionDate()
    {
        return CompletionDate;
    }
    public String getExamDate()
    {
        return ExamDate;
    }
    public String getPrerequisite()
    {
        return Prerequisite;
    }
    public boolean getIsRegistered()
    {
        return IsRegistered;
    }
    public boolean getIsRemoved()
    {
        return IsRemoved;
    }
    /**
     * This method is used to set new Instructor's name.
     */
    public void setInstructorName(String newInstructorName)
    {
        if(IsRegistered==false)
        {
            this.InstructorName=newInstructorName;
        }
        else
        {
            System.out.println("The course has already been registered. So, instructor name can't be changed");
        }
    }
    /**
     * This method is used to register the course.
     */
    public void register(String CourseLeader, String InstructorName, String StartDate, String CompletionDate, String ExamDate)
    {
        if (IsRegistered==false)
        {
            super.setCourseLeader(CourseLeader);
            this.InstructorName=InstructorName;
            this.StartDate= StartDate;
            this.CompletionDate=CompletionDate;
            this.ExamDate=ExamDate;
            this.IsRegistered=true;
        }
        else
        {
            System.out.println("The Course has been already registered");
        }
    }
    /**
     * This method is used to remove the course.
     */
    public void remove()
    {
        if(IsRemoved==true)
        {
            System.out.println("The course has been already removed");
        }
        else
        {
            super.setCourseLeader("");
            this.InstructorName="";
            this.StartDate="";
            this.CompletionDate="";
            this.ExamDate="";
            this.IsRegistered=false;
            this.IsRemoved=true;
        }
    }
    /**
     * This method is used to display the details of course.
     * It also haas same details as the display method of Parent class Course.
     */
    public void display()
    {
        super.display();
        if(IsRegistered==true)
        {
            System.out.println("The name of the instructor is "+ InstructorName);
            System.out.println("The prerequisite of the course is "+ Prerequisite);
            System.out.println("The starting Date of the course is "+ StartDate);
            System.out.println("The Completion Date of the course is "+ CompletionDate);
            System.out.println("The exam date of the course is "+ ExamDate);
        }
    }
}