#This module contains returning book and updating stock functions
import ListSplit
import DateTime

def returnBook():
    fName=input("Enter first name of borrower: ")
    lName=input("Enter last name of borrower: ")
    a="Details/Borrow-"+fName+ lName+".txt" #Checking borrowed txt file in Details folder
    try:
        with open(a,"r") as file:
            lines=file.readlines()#read file line wise
            lines=[a.strip("$") for a in lines]
    
        with open(a,"r") as file:
            data=file.read()
            print(data)
    except:
        print("The given borrower name is incorrect. \nPlease check name properly")
        returnBook()

    b="Details/Return-"+fName+ lName+".txt" #Creating txt file in Details folder
    with open(b,"w+")as file:
        file.write("-------------------------------------------------------- \n")
        file.write("               Library Management System                 \n")
        file.write("-------------------------------------------------------- \n")
        file.write("           *Returned By: "+ fName+" "+lName+"\n")
        file.write("---| Date: " + DateTime.getDate()+"  |-----|  Time:"+ DateTime.getTime()+" |---\n\n")
        file.write("________________________________________________________ \n")
        file.write("|S.N.|\t\t| Bookname  |\t\t| Cost |\n")
        file.write("________________________________________________________ \n")


    total=0.0
    for i in range(3):
        if ListSplit.bookname[i] in data:
            with open(b,"a") as file:
                file.write(str(i+1)+"\t\t"+ListSplit.bookname[i]+"\t\t$"+ListSplit.cost[i]+","+"\n")
                ListSplit.quantity[i]=int(ListSplit.quantity[i])+1
            total+=float(ListSplit.cost[i])
            
    print("\t\t\t\t\t\t\t"+"$"+str(total))
    print("Is the book returned after expiring date)?")
    print("Press Y for Yes and N for No")
    
    stat=input()
    if(stat.upper()=="Y"):
        print("By how many days was the book returned late?")
        d=int(input())
        fine=1*d
        with open(b,"a")as file:
            file.write("\t\t\t\t\tFine: $"+ str(fine)+"\n")
        total=total+fine
    


    print("Final Total: "+ "$"+str(total)) #calculating fine
    print("\nBook has been returned successfully \n")
    print ("\n---------------Thank you for returning books to us.---------------\n ------------------------Please visit again------------------------")
    with open(b,"a")as file:
        file.write("\t\t\t\t\tTotal: $"+ str(total))
    
        
    with open("BookStock.txt","w+") as file:
            for i in range(3):
                file.write(ListSplit.bookname[i]+","+ListSplit.authorname[i]+","+str(ListSplit.quantity[i])+","+"$"+ListSplit.cost[i]+","+"\n")
