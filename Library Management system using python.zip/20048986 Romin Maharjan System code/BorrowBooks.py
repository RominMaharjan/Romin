#This module contains borrowing books and updating the stocks functions

import DateTime
import ListSplit

def borrowBook():
    L=False
    while(True):
        fName=input("Please Enter the first name of the borrower: ")
        if fName.isalpha(): #Checking either name is alphabetical or not
            break
        print("Please input valid name \n Alphabet from A-Z")
    while(True):
        lName=input("Please Enter the last name of the borrower: ")
        if lName.isalpha():
            break
        print("Please input valid name \n Alphabet from A-Z")
              
    t="Details/Borrow-"+fName+ lName+".txt" #Creating txt file for borrow
    with open(t,"w+") as file:
        file.write("-------------------------------------------------------- \n")
        file.write("               Library Management System                 \n")
        file.write("-------------------------------------------------------- \n")
        file.write("           *Borrowed By: "+ fName+" "+lName+"\n")
        file.write("---| Date: " + DateTime.getDate()+"  |-----|  Time:"+ DateTime.getTime()+" |---\n\n")
        file.write("________________________________________________________ \n")

        file.write("|S.N. |\t\t| Bookname |\t\t|     Authorname |\n" )
        file.write("________________________________________________________ \n")

    while L==False:
        print("\nPlease select a option below: ")
        for i in range(len(ListSplit.bookname)):
            print("Enter", i, "to borrow book", ListSplit.bookname[i])
    
        try:   
            a=int(input())
            try:
                if(int(ListSplit.quantity[a])>0):
                    print("Selected Book is available\n")
                    choice=str(input("Are you sure you want to borrow this book? \nPlease select your type. Press y for yes and n for no."))
                    if(choice.upper()=="Y"):
                        with open(t,"a") as file:
                            file.write("1. \t\t"+ ListSplit.bookname[a]+"\t\t  "+ListSplit.authorname[a]+"\n")

                        ListSplit.quantity[a]=int(ListSplit.quantity[a])-1
                        with open("BookStock.txt","w+") as file:
                            for i in range(3):
                                file.write(ListSplit.bookname[i]+","+ListSplit.authorname[i]+","+str(ListSplit.quantity[i])+","+"$"+ListSplit.cost[i]+","+"\n")
                    else:
                        borrowBook()
                        L=False 
                    print ("\nBook has been successfully borrowed \n")
                    loop=True #For borrowing multiple books 
                    count=1
                    while loop==True:
                        choice=str(input("Do you want to borrow more books? \nNote: You cannot borrow same book twice. \nPlease select your type. Press y for yes and n for no."))
                        if(choice.upper()=="Y"):
                            count=count+1
                            print("\nPlease select an option below:")
                            for i in range(len(ListSplit.bookname)):
                                print("Enter", i, "to borrow book", ListSplit.bookname[i])
                            a=int(input())
                            if(int(ListSplit.quantity[a])>0):
                                print("Selected Book is available \n")
                                choice=str(input("Are you sure you want to borrow this book too? \nPlease select your type. Press y for yes and n for no."))
                                if(choice.upper()=="Y"):
                                    print("\nBook has been successfully borrowed \n")
                                    with open(t,"a") as file:
                                        file.write(str(count) +". \t\t"+ ListSplit.bookname[a]+"\t\t  "+ListSplit.authorname[a]+"\n")

                                    ListSplit.quantity[a]=int(ListSplit.quantity[a])-1
                                    with open("BookStock.txt","w+") as file:
                                        for i in range(3):
                                            file.write(ListSplit.bookname[i]+","+ListSplit.authorname[i]+","+str(ListSplit.quantity[i])+","+"$"+ListSplit.cost[i]+","+"\n") 
                                            L=False
                                else:
                                    borrowBook()
                                    L=False
                            else:
                                loop=False
                                break
                        elif (choice.upper()=="N"):
                            print ("\n---------------Thank you for borrowing books from us.---------------\n ------------------------Please visit again---------------------------")        
                            print("")
                            loop=False
                            L=True
                        else:
                            print("Please choose as instructed")
                        
                else:
                    print("Book is not available")
                    borrowBook()
                    L=False
            except IndexError:#handeling error
                print("")
                print("\n Please choose book acording to their number.")
        except ValueError:#handeling error
            print("")
            print("Please enter valid input.")
