#This is the main module of the application
#All the modules are imported here
#A begenning banner message is shown and proceed to run other modules.

import BorrowBooks
import Return
import ListSplit
import DateTime

def start():
    while(True):
        print ("-----------------------------------------------")
        print ("     Welcome to Library Management System      ")
        print ("----------------------------------------------- \n ")
        print ("Please Enter 1. To Display list of book")
        print ("Please Enter 2. To Borrow the book")
        print ("Please Enter 3. To Return the book")
        print ("Please Enter 0. To Exit")
        try:        #possible error detected so try,except is used
            a=int(input("\nPlease select your type from 0 to 3: "))
            print()
            if(a==1): #For display
                with open("BookStock.txt","r") as file:
                    b = file.readlines()
                    print(":  Book Name  :  Author         : Quantity : Price  :") #Creating table for appropriate display
                    for i in b:
                        item = i.split(",")
                        print(":",item[0]," "*(10-len(item[0])),":",
                              item[1]," "*(14-len(item[1])),":",
                              item[2]," "*(7-len(str(item[2]))),":",
                              item[3]," "*(5-len(str(item[3]))),":")
                        
   
            elif(a==2): #For borrowing books
                ListSplit.listSplit()
                BorrowBooks.borrowBook()
            elif(a==3): #For Returning books
                ListSplit.listSplit()
                Return.returnBook()
            elif(a==0): #For closing program
                print ("\n---------------Thank you for choosing us.---------------\n------------------Please visit again---------------------\n")
                choice=str(input("Are you sure you want to exit? \nPlease select your type. Press y for yes and n for no."))
                if(choice.upper()=="Y"):
                    break
            else:
                print("\nPlease enter positive valid number from 0-3")
        except ValueError:#Handeling Error
            print("Please enter valid input.")
start()

