/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MovieTheatre_IS;

/**
 *
 * @author Romin
 */
public class SelectionSorter {
    //for sorting
    public static void sort(int[] a){
        for(int i = 0; i < a.length-1; i++){
            int minPos = minimumPosition(a,i);
            swap(a,minPos,i);
        }
    }
    
    //for swapping
    public static void swap(int[] a, int i, int j){
        int temp = a[i];
        a[i] = a[j];
        a[j] = temp;
    }
    
    //to determine the lowest value in the array to swap with minimum position
    public static int minimumPosition (int[] a, int from){
        int minPos = from;
        for(int i = from+1; i < a.length; i++){
            if (a[i] < a[minPos]){
                minPos = i;
            }
        }
        return minPos;
    }
}
