/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MovieTheatre_IS;

/**
 *
 * @author Romin
 */
public class DataModel {
    String Name, Genre, Rating, Director, Type;
    int Ticket;
        
    DataModel(String Name, String Genre, String Rating, String Director, String Type, int Ticket){
        this.Name=Name;
        this.Genre=Genre;
        this.Rating=Rating;
        this.Director=Director;
        this.Type=Type;
        this.Ticket=Ticket;
    }
    
    String getName(){
        return Name;
    }
    
    String getGenre(){
        return Genre;
    }
    
    String getRating(){
        return Rating;
    }
    String getDirector(){
        return Director;
    }
    
    String getType(){
        return Type;
    }
    
    int getTicket(){
        return Ticket;
    }

    String get() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
